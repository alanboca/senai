package imovelProjeto;

import java.util.Date;

public class Main {
    public static void main(String[] args) {
        // Crie instâncias de Corretor, Proprietario, Locatario, Casa e Apartamento
        Corretor corretor = new Corretor("João", "123-456-7890", "Rua A", "123456789", "C123", new Date(), 0.10);
        Locatario locatario = new Locatario("Paulo", "555555", "Rua X", "2222222", "paulo@email.com", "5000"); // Campos de nome, telefone, endereço e CPF estão vazios
        Proprietario proprietario = new Proprietario("Maria", "987-654-3210", "Rua B", "987654321", "789012", "A789");
        Casa casa = new Casa(1, "Rua X", 1500, 2, 3, 2, 2, proprietario);
        Apartamento apartamento = new Apartamento(2, "Rua Y", 1200, 1, 2, 1, 5, 501, 300, 50, 100, proprietario);


        // Cálculo do aluguel
        double aluguelCasa = casa.calcularAluguel();
        double aluguelApartamento = apartamento.calcularAluguel();

        System.out.println("Aluguel da casa: R$" + aluguelCasa);
        System.out.println("Aluguel do apartamento: R$" + aluguelApartamento);

        // Criação de uma locação
        Date dataInicioCasa = new Date();
        Date dataTerminoCasa = new Date();
        Date dataPagamentoCasa = new Date();

        //locação apartamento
        Date dataInicioAp = new Date();
        Date dataTerminoAp = new Date();
        Date dataPagamentoAp = new Date();


        Locacao locacaoCasa = new Locacao(dataInicioCasa, dataTerminoCasa, dataPagamentoCasa, locatario, casa, corretor, proprietario);
        Locacao locacaoApartamento = new Locacao(dataInicioAp, dataTerminoAp, dataPagamentoAp, locatario, apartamento, corretor, proprietario);

        // Enviar cobrança e pagar proprietário
        locacaoCasa.enviarCobranca();
        locacaoCasa.pagarProprietario();

        // Enviar cobrança e pagar proprietário Apartamento
        locacaoApartamento.enviarCobranca();
        locacaoApartamento.pagarProprietario();
    }
}