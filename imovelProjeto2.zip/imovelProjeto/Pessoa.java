package imovelProjeto;

public abstract class Pessoa implements ReceberValor {
    private String nome;
    private String telefone;
    private String endereco;
    private String cpf;

    public Pessoa(String nome, String telefone, String endereco, String cpf) {
        this.nome = nome;
        this.telefone = telefone;
        this.endereco = endereco;
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    // Outros getters e setters

    @Override
    public void receber(double valor) {
        // Implementação para receber valor
    }
}





