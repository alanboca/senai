package imovelProjeto;

public interface ReceberValor {
    void receber(double valor);
}
